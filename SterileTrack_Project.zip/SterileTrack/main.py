from datetime import datetime, timezone
from pathlib import Path
from typing import Optional
import logging
import uuid

from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from database import init_db, create_batch, get_batch, list_batches, update_validation, release_batch, add_audit, get_audit
from services.batch_service import make_batch
from services.validation_service import validate_batch
from services.release_service import decide_release
from security import require_role

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("steriletrack")

app = FastAPI(title="SterileTrack API", version="1.0.0",
              description="Academic demo for sterilization batch traceability and release review.")

ROOT = Path(__file__).resolve().parent
app.mount("/static", StaticFiles(directory=ROOT / "frontend"), name="static")

# Simple in-process service registry for the classroom demonstration.
SERVICE_REGISTRY = {
    "batch-service": {"module": "services.batch_service", "status": "registered"},
    "validation-service": {"module": "services.validation_service", "status": "registered"},
    "release-service": {"module": "services.release_service", "status": "registered"},
}

@app.on_event("startup")
def startup():
    init_db()
    logger.info("SterileTrack started; service registry loaded: %s", list(SERVICE_REGISTRY))

@app.middleware("http")
async def observe_requests(request: Request, call_next):
    request_id = request.headers.get("X-Request-ID", str(uuid.uuid4()))
    start = datetime.now(timezone.utc)
    try:
        response = await call_next(request)
        response.headers["X-Request-ID"] = request_id
        elapsed = (datetime.now(timezone.utc) - start).total_seconds()
        logger.info("request_id=%s method=%s path=%s status=%s duration=%.4fs",
                    request_id, request.method, request.url.path, response.status_code, elapsed)
        return response
    except Exception:
        logger.exception("request_id=%s unhandled request error", request_id)
        raise

class BatchInput(BaseModel):
    batch_id: str = Field(min_length=2, max_length=30)
    equipment: str = Field(min_length=2, max_length=100)
    operator: str = Field(min_length=2, max_length=80)
    temperature_c: float = Field(ge=0, le=200)
    exposure_minutes: int = Field(ge=0, le=600)
    pressure_kpa: float = Field(ge=0, le=1000)
    indicator_passed: bool
    load_record_complete: bool
    notes: str = Field(default="", max_length=500)

class ReleaseInput(BaseModel):
    decision: str = Field(pattern="^(approve|hold)$")
    reason: str = Field(min_length=3, max_length=300)

def current_user(x_api_key: Optional[str], x_role: Optional[str]):
    # Demo credentials only. Replace with proper identity management for production.
    if x_api_key not in {"demo-operator-key", "demo-supervisor-key"}:
        raise HTTPException(status_code=401, detail="Missing or invalid demo API key")
    expected_role = "supervisor" if x_api_key == "demo-supervisor-key" else "operator"
    role = (x_role or expected_role).lower()
    if role != expected_role:
        raise HTTPException(status_code=403, detail="Role does not match API key")
    return {"role": role}

@app.get("/", include_in_schema=False)
def home():
    return FileResponse(ROOT / "frontend" / "index.html")

@app.get("/api/health")
def health():
    return {"status": "ok", "application": "SterileTrack", "database": "sqlite",
            "registered_services": len(SERVICE_REGISTRY)}

@app.get("/api/services")
def discover_services():
    """Demonstration registry: gateway can identify the service responsible for each capability."""
    return SERVICE_REGISTRY

@app.get("/api/batches")
def batches():
    return {"batches": list_batches()}

@app.post("/api/batches", status_code=201)
def register_batch(payload: BatchInput, x_api_key: Optional[str] = Header(default=None),
                   x_role: Optional[str] = Header(default=None), x_request_id: Optional[str] = Header(default=None)):
    user = current_user(x_api_key, x_role)
    require_role(user["role"], {"operator", "supervisor"})
    existing = get_batch(payload.batch_id)
    if existing:
        raise HTTPException(status_code=409, detail="Batch ID already exists")
    data = make_batch(payload.model_dump())
    create_batch(data)
    add_audit(payload.batch_id, user["role"], "REGISTERED", "Batch created", x_request_id)
    logger.info("batch_service handled registration for %s", payload.batch_id)
    return data

@app.get("/api/batches/{batch_id}")
def batch_detail(batch_id: str):
    batch = get_batch(batch_id)
    if not batch:
        raise HTTPException(status_code=404, detail="Batch not found")
    return batch

@app.post("/api/batches/{batch_id}/validate")
def validate(batch_id: str, x_api_key: Optional[str] = Header(default=None),
             x_role: Optional[str] = Header(default=None), x_request_id: Optional[str] = Header(default=None)):
    user = current_user(x_api_key, x_role)
    require_role(user["role"], {"operator", "supervisor"})
    batch = get_batch(batch_id)
    if not batch:
        raise HTTPException(status_code=404, detail="Batch not found")
    result = validate_batch(batch)
    update_validation(batch_id, result)
    action = "VALIDATION_PASSED" if result["eligible_for_review"] else "VALIDATION_FAILED"
    add_audit(batch_id, user["role"], action, "; ".join(result["issues"]) or "All configured demo checks passed", x_request_id)
    return {"batch_id": batch_id, **result}

@app.post("/api/batches/{batch_id}/release")
def release(batch_id: str, payload: ReleaseInput,
            x_api_key: Optional[str] = Header(default=None), x_role: Optional[str] = Header(default=None),
            x_request_id: Optional[str] = Header(default=None)):
    user = current_user(x_api_key, x_role)
    require_role(user["role"], {"supervisor"})
    batch = get_batch(batch_id)
    if not batch:
        raise HTTPException(status_code=404, detail="Batch not found")
    result = decide_release(batch, payload.decision, payload.reason)
    if result["status"] == "RELEASED":
        release_batch(batch_id, result["status"], user["role"], payload.reason)
        add_audit(batch_id, user["role"], "RELEASED", payload.reason, x_request_id)
    else:
        # Hold is allowed regardless of validation; never release an ineligible batch.
        release_batch(batch_id, result["status"], user["role"], payload.reason)
        add_audit(batch_id, user["role"], "ON_HOLD", payload.reason, x_request_id)
    return result

@app.get("/api/batches/{batch_id}/audit")
def batch_audit(batch_id: str):
    if not get_batch(batch_id):
        raise HTTPException(status_code=404, detail="Batch not found")
    return {"events": get_audit(batch_id)}

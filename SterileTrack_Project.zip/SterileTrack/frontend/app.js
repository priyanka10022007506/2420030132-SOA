const API = "/api";
const OPERATOR_KEY = "demo-operator-key";
const SUPERVISOR_KEY = "demo-supervisor-key";
const $ = (id) => document.getElementById(id);

function showOutput(title, data) {
  $("detailIntro").textContent = title;
  $("output").textContent = typeof data === "string" ? data : JSON.stringify(data, null, 2);
}
async function api(path, options = {}, role = "operator") {
  const headers = { "Content-Type": "application/json", "X-API-Key": role === "supervisor" ? SUPERVISOR_KEY : OPERATOR_KEY, "X-Role": role, "X-Request-ID": crypto.randomUUID(), ...(options.headers || {}) };
  const response = await fetch(API + path, { ...options, headers });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.detail || `Request failed: ${response.status}`);
  return body;
}
function statusPill(status) {
  const s = status || "PENDING_CHECKS";
  const cls = ["RELEASED","ELIGIBLE_FOR_REVIEW"].includes(s) ? "green" : ["ON_HOLD"].includes(s) ? "red" : "amber";
  return `<span class="pill ${cls}">${s.replaceAll("_"," ")}</span>`;
}
async function loadBatches() {
  try {
    const result = await api("/batches", {}, "operator");
    const batches = result.batches || [];
    $("totalCount").textContent = batches.length;
    $("eligibleCount").textContent = batches.filter(b => b.status === "ELIGIBLE_FOR_REVIEW" || b.status === "RELEASED").length;
    $("holdCount").textContent = batches.filter(b => !["ELIGIBLE_FOR_REVIEW","RELEASED"].includes(b.status)).length;
    if (!batches.length) {
      $("batchRows").innerHTML = '<tr><td colspan="6">No batches yet. Register your first batch above.</td></tr>';
      return;
    }
    $("batchRows").innerHTML = batches.map(b => `<tr>
      <td class="batch-id">${escapeHtml(b.batch_id)}</td><td>${escapeHtml(b.equipment)}</td>
      <td>${b.temperature_c} °C</td><td>${statusPill(b.validation_status)}</td><td>${statusPill(b.status)}</td>
      <td><div class="actions">
        <button class="light" onclick="validateBatch('${safeId(b.batch_id)}')">Validate</button>
        <button class="dark" onclick="approveBatch('${safeId(b.batch_id)}')">Review</button>
        <button class="light" onclick="auditBatch('${safeId(b.batch_id)}')">Audit</button>
      </div></td></tr>`).join("");
  } catch (e) { showOutput("Could not load batches", e.message); }
}
function escapeHtml(value) { return String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
function safeId(value) { return encodeURIComponent(value).replaceAll("%","%25"); }

$("batchForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const fd = new FormData(form);
  const data = {
    batch_id: fd.get("batch_id").trim().toUpperCase(), equipment: fd.get("equipment").trim(),
    operator: fd.get("operator").trim(), temperature_c: Number(fd.get("temperature_c")),
    exposure_minutes: Number(fd.get("exposure_minutes")), pressure_kpa: Number(fd.get("pressure_kpa")),
    indicator_passed: fd.has("indicator_passed"), load_record_complete: fd.has("load_record_complete"),
    notes: fd.get("notes") || ""
  };
  try {
    const result = await api("/batches", { method:"POST", body:JSON.stringify(data) });
    showOutput("Batch registered successfully", result);
    form.reset(); form.elements.temperature_c.value = 121; form.elements.exposure_minutes.value = 15; form.elements.pressure_kpa.value = 200;
    form.elements.indicator_passed.checked = true; form.elements.load_record_complete.checked = true;
    await loadBatches();
  } catch (e) { showOutput("Registration failed", e.message); }
});
async function validateBatch(id) {
  try {
    const result = await api(`/batches/${id}/validate`, {method:"POST"});
    showOutput(`Validation result for ${id}`, result); await loadBatches();
  } catch (e) { showOutput("Validation failed", e.message); }
}
async function approveBatch(id) {
  const action = prompt("Type APPROVE to record release, or HOLD to keep the batch on hold:");
  if (!action) return;
  const decision = action.trim().toLowerCase();
  if (!["approve","hold"].includes(decision)) { showOutput("Review cancelled", "Please enter APPROVE or HOLD."); return; }
  const reason = prompt("Enter a reason for the supervisor decision (required):");
  if (!reason || reason.trim().length < 3) { showOutput("Review cancelled", "A reason of at least 3 characters is required."); return; }
  try {
    const result = await api(`/batches/${id}/release`, {method:"POST", body:JSON.stringify({decision, reason:reason.trim()})}, "supervisor");
    showOutput(`Supervisor decision for ${id}`, result); await loadBatches();
  } catch (e) { showOutput("Release review rejected", e.message); }
}
async function auditBatch(id) {
  try { const result = await api(`/batches/${id}/audit`); showOutput(`Audit history for ${id}`, result); }
  catch (e) { showOutput("Audit lookup failed", e.message); }
}
(async () => {
  try {
    const [health, services] = await Promise.all([fetch(API+"/health").then(r=>r.json()), fetch(API+"/services").then(r=>r.json())]);
    showOutput("System health and service registry", {health, services});
  } catch(e) { showOutput("System startup", e.message); }
  await loadBatches();
})();

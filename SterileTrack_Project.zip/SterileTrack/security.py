from fastapi import HTTPException

def require_role(role: str, allowed_roles: set[str]):
    if role not in allowed_roles:
        raise HTTPException(status_code=403, detail="Insufficient permissions")

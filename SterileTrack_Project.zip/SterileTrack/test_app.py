import os
import tempfile
from fastapi.testclient import TestClient
import database

# Keep test data separate from the user's demo database.
_test_db = os.path.join(tempfile.gettempdir(), "steriletrack_test.db")
database.DB_PATH = __import__("pathlib").Path(_test_db)

from main import app

client = TestClient(app)
OP = {"X-API-Key": "demo-operator-key", "X-Role": "operator"}
SUP = {"X-API-Key": "demo-supervisor-key", "X-Role": "supervisor"}

def setup_function():
    database.init_db()
    with database.connect() as conn:
        conn.execute("DELETE FROM audit_events")
        conn.execute("DELETE FROM batches")

def sample(batch_id="TEST-001", temperature=121, indicator=True, complete=True):
    return {
        "batch_id": batch_id, "equipment": "Surgical instrument tray", "operator": "Demo Operator",
        "temperature_c": temperature, "exposure_minutes": 15, "pressure_kpa": 200,
        "indicator_passed": indicator, "load_record_complete": complete, "notes": "Test batch"
    }

def test_health_and_service_registry():
    assert client.get("/api/health").status_code == 200
    assert "batch-service" in client.get("/api/services").json()

def test_registration_requires_authentication():
    assert client.post("/api/batches", json=sample()).status_code == 401

def test_batch_registration_and_validation_pass():
    assert client.post("/api/batches", json=sample(), headers=OP).status_code == 201
    result = client.post("/api/batches/TEST-001/validate", headers=OP)
    assert result.status_code == 200
    assert result.json()["eligible_for_review"] is True

def test_failed_indicator_keeps_batch_on_hold():
    client.post("/api/batches", json=sample("TEST-002", indicator=False), headers=OP)
    result = client.post("/api/batches/TEST-002/validate", headers=OP)
    assert result.json()["eligible_for_review"] is False
    assert any("indicator" in issue.lower() for issue in result.json()["issues"])

def test_operator_cannot_release():
    client.post("/api/batches", json=sample("TEST-003"), headers=OP)
    response = client.post("/api/batches/TEST-003/release",
                           json={"decision":"approve","reason":"Looks fine"}, headers=OP)
    assert response.status_code == 403

def test_cannot_release_before_validation():
    client.post("/api/batches", json=sample("TEST-004"), headers=OP)
    response = client.post("/api/batches/TEST-004/release",
                           json={"decision":"approve","reason":"Approved after review"}, headers=SUP)
    assert response.status_code == 409

def test_supervisor_can_release_after_validation():
    client.post("/api/batches", json=sample("TEST-005"), headers=OP)
    client.post("/api/batches/TEST-005/validate", headers=OP)
    response = client.post("/api/batches/TEST-005/release",
                           json={"decision":"approve","reason":"Demo approval"}, headers=SUP)
    assert response.status_code == 200
    assert response.json()["status"] == "RELEASED"

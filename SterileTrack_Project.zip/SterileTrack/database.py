import sqlite3
from pathlib import Path
from datetime import datetime, timezone
import json

DB_PATH = Path(__file__).resolve().parent / "steriletrack.db"

def connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with connect() as conn:
        conn.execute("""
        CREATE TABLE IF NOT EXISTS batches (
            batch_id TEXT PRIMARY KEY, equipment TEXT NOT NULL, operator TEXT NOT NULL,
            temperature_c REAL NOT NULL, exposure_minutes INTEGER NOT NULL, pressure_kpa REAL NOT NULL,
            indicator_passed INTEGER NOT NULL, load_record_complete INTEGER NOT NULL, notes TEXT NOT NULL,
            validation_status TEXT NOT NULL DEFAULT 'PENDING',
            validation_issues TEXT NOT NULL DEFAULT '[]',
            status TEXT NOT NULL DEFAULT 'PENDING_CHECKS',
            released_by TEXT, release_reason TEXT, updated_at TEXT NOT NULL
        )""")
        conn.execute("""
        CREATE TABLE IF NOT EXISTS audit_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT, batch_id TEXT NOT NULL, actor TEXT NOT NULL,
            action TEXT NOT NULL, reason TEXT NOT NULL, request_id TEXT, created_at TEXT NOT NULL
        )""")

def row_to_dict(row):
    if row is None:
        return None
    d = dict(row)
    d["indicator_passed"] = bool(d["indicator_passed"])
    d["load_record_complete"] = bool(d["load_record_complete"])
    d["validation_issues"] = json.loads(d["validation_issues"])
    return d

def create_batch(data):
    with connect() as conn:
        conn.execute("""INSERT INTO batches
        (batch_id,equipment,operator,temperature_c,exposure_minutes,pressure_kpa,
         indicator_passed,load_record_complete,notes,updated_at)
        VALUES (?,?,?,?,?,?,?,?,?,?)""",
        (data["batch_id"], data["equipment"], data["operator"], data["temperature_c"],
         data["exposure_minutes"], data["pressure_kpa"], int(data["indicator_passed"]),
         int(data["load_record_complete"]), data["notes"], now()))
    return get_batch(data["batch_id"])

def get_batch(batch_id):
    with connect() as conn:
        row = conn.execute("SELECT * FROM batches WHERE batch_id=?", (batch_id,)).fetchone()
    return row_to_dict(row)

def list_batches():
    with connect() as conn:
        rows = conn.execute("SELECT * FROM batches ORDER BY updated_at DESC").fetchall()
    return [row_to_dict(r) for r in rows]

def update_validation(batch_id, result):
    status = "ELIGIBLE_FOR_REVIEW" if result["eligible_for_review"] else "ON_HOLD"
    with connect() as conn:
        conn.execute("""UPDATE batches SET validation_status=?, validation_issues=?, status=?, updated_at=?
                        WHERE batch_id=?""",
                     ("PASSED" if result["eligible_for_review"] else "FAILED",
                      json.dumps(result["issues"]), status, now(), batch_id))

def release_batch(batch_id, status, role, reason):
    with connect() as conn:
        conn.execute("""UPDATE batches SET status=?, released_by=?, release_reason=?, updated_at=?
                        WHERE batch_id=?""", (status, role, reason, now(), batch_id))

def add_audit(batch_id, actor, action, reason, request_id=None):
    with connect() as conn:
        conn.execute("""INSERT INTO audit_events(batch_id,actor,action,reason,request_id,created_at)
                        VALUES(?,?,?,?,?,?)""",
                     (batch_id, actor, action, reason, request_id, now()))

def get_audit(batch_id):
    with connect() as conn:
        rows = conn.execute("SELECT * FROM audit_events WHERE batch_id=? ORDER BY id DESC", (batch_id,)).fetchall()
    return [dict(r) for r in rows]

def now():
    return datetime.now(timezone.utc).isoformat()

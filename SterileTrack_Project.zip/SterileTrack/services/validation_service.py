def validate_batch(batch: dict) -> dict:
    """
    Demo-only validation thresholds, not clinical instructions.
    In a real facility, use validated cycle-specific parameters and approved procedures.
    """
    issues = []
    # Illustrative values solely for demonstrating software validation logic.
    if batch["temperature_c"] < 121:
        issues.append("Temperature is below the configured demo threshold (121 C).")
    if batch["exposure_minutes"] < 15:
        issues.append("Exposure time is below the configured demo threshold (15 minutes).")
    if batch["pressure_kpa"] <= 0:
        issues.append("Pressure reading must be greater than zero.")
    if not batch["indicator_passed"]:
        issues.append("Required indicator result did not pass.")
    if not batch["load_record_complete"]:
        issues.append("Load record is incomplete.")
    eligible = len(issues) == 0
    return {
        "eligible_for_review": eligible,
        "validation_status": "PASSED" if eligible else "FAILED",
        "issues": issues,
        "message": "Eligible for authorized review." if eligible else "Batch placed on hold; resolve all issues."
    }

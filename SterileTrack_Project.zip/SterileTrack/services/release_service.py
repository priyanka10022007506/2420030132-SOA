def decide_release(batch: dict, decision: str, reason: str) -> dict:
    if decision == "approve":
        if batch.get("validation_status") != "PASSED" or batch.get("status") != "ELIGIBLE_FOR_REVIEW":
            from fastapi import HTTPException
            raise HTTPException(status_code=409, detail="Cannot release: validation must pass first.")
        return {"batch_id": batch["batch_id"], "status": "RELEASED",
                "message": "Demo release recorded after validation and supervisor approval."}
    return {"batch_id": batch["batch_id"], "status": "ON_HOLD",
            "message": "Batch placed on hold by supervisor.", "reason": reason}

def make_batch(data: dict) -> dict:
    """Normalize incoming batch data before it is persisted."""
    cleaned = dict(data)
    cleaned["batch_id"] = cleaned["batch_id"].strip().upper()
    cleaned["equipment"] = cleaned["equipment"].strip()
    cleaned["operator"] = cleaned["operator"].strip()
    cleaned["notes"] = cleaned.get("notes", "").strip()
    cleaned["validation_status"] = "PENDING"
    cleaned["validation_issues"] = []
    cleaned["status"] = "PENDING_CHECKS"
    return cleaned
